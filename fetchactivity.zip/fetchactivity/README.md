# Fetch Activity
https://github.com/ajacqmin/IS424/tree/main/fetchactivity
